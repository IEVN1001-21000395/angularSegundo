import {Routes} from "@angular/router";

export default[
    {
        path: 'resistencia1',
        loadComponent:()=>import('./resistencia1.component'),
    },
    
]as Routes